# Correos de compra FemTech

Abre purchase-emails/index.html en el navegador para revisar los 12 diseños.
Lee purchase-emails/HANDOFF-CLAUDE-GHL.md y WORKFLOWS.md para implementar.
Usa templates/ para GHL; preview/ solo para revisión. Los contactos y enlaces son pendientes, no conexiones reales. No se ha enviado ningún correo.

Los skylines están incluidos en purchase-emails/assets/. Textos en COPY-EMAILS.md. El repositorio completo y sus pruebas están en https://github.com/Mayra-Prelude/TJ26.
