# FemTech México — tres páginas en español

La versión vigente usa el diseño de skyline oscuro/rosa de la agenda y el newsletter. Empieza por handoff/TRANSFERENCIA-CLAUDE.md. Para compartir con Claude, lee handoff/COMO-COMPARTIR-CON-CLAUDE.md y copia el texto de handoff/PEGAR-EN-CLAUDE.txt. El correo contiene 9 actividades hasta el 6 de noviembre, sin Lisboa. La web conserva 10 actividades. Ver handoff/IMAGENES.md para distinguir imágenes incluidas y originales pendientes, y handoff/COPY-CLARO.md para redacción breve.

1. Revisa la agenda en newsletter/index.html y el correo en newsletter/email.html (vista autónoma con imágenes incrustadas). Para implementar en GHL usa newsletter/email-ghl.html y sustituye las rutas por URLs HTTPS de imágenes alojadas.
2. Abre sponsorship-designs/index.html para las páginas independientes de Tijuana y CDMX.
3. Lee sponsorship-designs/HANDOFF-CLAUDE-GHL.md. Cada *-ghl-block.html va en un elemento Custom Code / HTML de GHL. Seguir sponsorship-designs/AIRTABLE-GHL-REGISTRO-VIP.md para enlazar el Airtable existente con el pago GHL. No requiere compilación.
4. Consulta newsletter/EVENTS-AND-ACCESS.md para fechas, contenido, registro y diferencias entre gratuito, pase VIP, invitación y eventos externos.
5. Los originales de imagen siguen pendientes; la carpeta Drive y el mapa de colocación están en newsletter/HANDOFF-CLAUDE-GHL.md y newsletter/handoff/asset-map.json.

Oferta vigente: Tijuana, pase de tres días USD 650 individual o USD 980 dúo, con traslados entre sedes oficiales y SIN comidas incluidas, según el último contenido adjunto; sustituye el modelo anterior sin precio. CDMX: Pase VIP Gold de cinco accesos, MXN 30,000 de referencia con impuestos/condiciones por confirmar. GHL debe verificar PayPal, moneda USD, el total reportado S$0.00 y la reserva vinculada a Airtable. Registrar allí empresa, logotipo y nombre/contacto de cada persona: dos lugares = dos asistentes; cinco lugares = cinco asistentes. Los diseños no capturan datos ni procesan pagos.

Agenda corregida: 10 actividades, un Summit el 30, una experiencia VIP el 31 y sin MedSummit. Mayra participará junto con Jill Biden según la organización; seguir newsletter/handoff/MILKEN-GMAIL-PENDIENTE.md para verificar los detalles en Gmail al construir GHL.

Capturas en previews/. Nada se publicó, envió ni cobró. El contenido de GHL fue proporcionado por la usuaria; no se verificó la cuenta desde esta sesión.

Desarrollo opcional: npm ci; npm run dev:sponsorships (3020) o npm run dev:newsletter (3010). Regenerar correo: npm run build:newsletter; python3 newsletter/package-email.py. Chromium en /usr/bin/chromium o CHROMIUM_PATH. Verificación: npm run test:sponsorships y npm run test:newsletter.
